g++ pagerank.cc -o pagerank -O3 -fopenmp
